# Stack & System — Production Repair Notes

This repair preserves the existing visual/content foundation and fixes the frontend defects identified in the V2 audit.

## Completed

- Added Start Here + dedicated AI Tools, AI Agents, AI Workflows and AI Business Ideas pages.
- Repaired mobile navigation with keyboard/Escape support and `aria-expanded`.
- Added skip link and current-page navigation semantics.
- Added form labels, live status regions and safer form validation.
- Removed localStorage-based fake newsletter signup.
- Removed localStorage-based fake authentication.
- Added reduced-motion handling.
- Added self-referencing canonical metadata plus Open Graph/Twitter metadata scaffolding; absolute `og:url`/sitemap values are intentionally deferred until the real production domain is known.
- Added privacy, terms and affiliate disclosure pages.
- Added `robots.txt` and a 404 page. The sitemap is intentionally deferred until the real production domain is known.
- Kept official tool destinations and avoided invented affiliate URLs.
- Kept product/marketplace CTAs honest: no fake checkout or payment claims.

## Intentional launch blockers

The static repository cannot honestly implement these without selecting and configuring real services:

1. Newsletter provider + API/serverless endpoint + consent flow.
2. Authentication provider + session management.
3. Marketplace product database/catalog.
4. Payment processor and verified webhook handling.
5. Secure digital-product delivery.
6. Production security headers/CSP/HSTS at the hosting layer.
7. Final legal copy based on actual providers and jurisdiction.
8. Exact approved affiliate URLs after partner approval.

Do not wire these to localStorage as a substitute for production infrastructure.

## Deployment

Before deployment, add absolute Open Graph URLs and generate a sitemap using the real canonical production domain.
