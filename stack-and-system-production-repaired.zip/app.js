(() => {
  "use strict";

  const qs = (selector, scope = document) => scope.querySelector(selector);
  const qsa = (selector, scope = document) => [...scope.querySelectorAll(selector)];

  qsa("[data-year]").forEach(el => {
    el.textContent = String(new Date().getFullYear());
  });

  // Current page state for accessible navigation.
  const current = location.pathname.split("/").pop() || "index.html";
  qsa(".nav-links a").forEach(link => {
    const href = link.getAttribute("href");
    if (href === current) {
      link.setAttribute("aria-current", "page");
    }
  });

  // Mobile navigation.
  const menuButton = qs(".mobile-toggle");
  const nav = qs("#primary-nav");
  if (menuButton && nav) {
    const closeMenu = () => {
      nav.classList.remove("is-open");
      menuButton.setAttribute("aria-expanded", "false");
      menuButton.setAttribute("aria-label", "Open menu");
    };
    menuButton.addEventListener("click", () => {
      const open = nav.classList.toggle("is-open");
      menuButton.setAttribute("aria-expanded", String(open));
      menuButton.setAttribute("aria-label", open ? "Close menu" : "Open menu");
    });
    qsa("a", nav).forEach(link => link.addEventListener("click", closeMenu));
    document.addEventListener("keydown", e => {
      if (e.key === "Escape") closeMenu();
    });
  }

  // Forms are intentionally provider-ready but do not fake persistence.
  qsa("[data-newsletter]").forEach(form => {
    form.addEventListener("submit", event => {
      event.preventDefault();
      const email = qs('input[type="email"]', form);
      const status = qs("[data-form-status]", form);
      if (!email || !status) return;

      if (!email.checkValidity()) {
        status.textContent = "Enter a valid email address.";
        email.focus();
        return;
      }

      status.textContent =
        "The newsletter provider is not connected yet, so no email was stored or submitted.";
    });
  });

  qsa("[data-signin]").forEach(form => {
    form.addEventListener("submit", event => {
      event.preventDefault();
      const email = qs('[name="email"]', form);
      const password = qs('[name="password"]', form);
      const status = qs("[data-form-status]", form);
      if (!email || !password || !status) return;

      if (!form.checkValidity()) {
        status.textContent = "Enter your email and password.";
        form.reportValidity();
        return;
      }

      status.textContent =
        "Authentication is not connected yet. No credentials were stored.";
    });
  });

  // Respect reduced-motion preferences.
  const reduceMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  const visual = qs(".hero-visual");
  if (visual && !reduceMotion) {
    const nodes = qsa(".node", visual);
    visual.addEventListener("pointermove", event => {
      const rect = visual.getBoundingClientRect();
      const x = (event.clientX - rect.left) / rect.width - 0.5;
      const y = (event.clientY - rect.top) / rect.height - 0.5;
      nodes.forEach((node, index) => {
        const depth = (index % 3 + 1) * 7;
        node.style.transform =
          `translate(calc(-50% + ${x * depth}px), calc(-50% + ${y * depth}px))`;
      });
    });
    visual.addEventListener("pointerleave", () => {
      nodes.forEach(node => {
        node.style.transform = "translate(-50%,-50%)";
      });
    });
  }
})();
